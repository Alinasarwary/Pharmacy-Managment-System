package hu.cs.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import hu.cs.demo.model.User;
import hu.cs.demo.repository.UserRepository;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		User initialuUser = userRepository.findByUsername("admin");

		if(initialuUser == null){
			User user1 = new User("AlinaSarwary", "admin", "admin@gmail.com", bCryptPasswordEncoder.encode("admin"));
			userRepository.save(user1);
		}

	}

}
