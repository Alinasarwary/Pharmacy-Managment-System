package hu.cs.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.demo.dto.MedicineDTO;
import hu.cs.demo.model.*;
// import hu.cs.demo.services.CompanyService;
import hu.cs.demo.services.MedicineService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;



@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class MedicineController { 

  @Autowired
  private MedicineService medicineservice;

  // @Autowired 
  // private CompanyService companyService;

    @GetMapping("/medicine/all")
    @ResponseBody
    public ResponseEntity<List<MedicineDTO>> getMedicine(){
      List<Medicine> medicines = medicineservice.getAllMedicine();
      List<MedicineDTO> medicineDTOList = medicineservice.ConvertMedicineToDTO(medicines);
        return new ResponseEntity<>(medicineDTOList, HttpStatus.ACCEPTED);

    }

    @PostMapping("/medicine/add")
    public ResponseEntity<Medicine> addMedicine(@RequestBody Medicine medicine){

      Medicine savedMedicine=  medicineservice.addMedicine(medicine);
      // MedicineDTO medicineDTO = medicineservice.ConvertMedicineToDTO(savedMedicine);
        return new ResponseEntity<>(savedMedicine, HttpStatus.CREATED);
    }

    @GetMapping("/medicine/{id}")
    public ResponseEntity<Medicine> getMedicine(@PathVariable("id")  Integer id){
      Medicine medicine= medicineservice.getMedicineById(id);
      return new ResponseEntity<>(medicine,HttpStatus.OK);

    }

    @PutMapping("/medicine/update")
    public ResponseEntity<Medicine> UpdateMedicine(@RequestBody Medicine medicine){
        
      Medicine savedMedicine=  medicineservice.addMedicine(medicine);
        return new ResponseEntity<>(savedMedicine,HttpStatus.OK);
  
    }
    
    @DeleteMapping("/medicine/{id}/delete")
    public  ResponseEntity<String> deleteMedicine(@PathVariable("id") Integer id){
      medicineservice.deleteMedicineById(id);

        return new ResponseEntity<>("Medicine" + id + "delete",HttpStatus.OK);
    }
      
    
  
}

