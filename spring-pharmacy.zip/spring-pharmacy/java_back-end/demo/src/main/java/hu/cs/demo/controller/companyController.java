package hu.cs.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.demo.dto.CompanyDTO;
import hu.cs.demo.model.Company;
import hu.cs.demo.services.CompanyService;
// import hu.cs.demo.services.stockServices;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class companyController {
  @Autowired
  private CompanyService companyService;
  
  // @Autowired
  // private stockServices stockservices;

    @PostMapping("/company/add")
    public ResponseEntity<CompanyDTO> addCompany(@RequestBody Company company){

      // company.setStock(stockservices.getById(1));

      Company savedCompany=  companyService.addCompany(company);
      CompanyDTO companyDTO = companyService.convertCompanyToDTO(savedCompany);
        return new ResponseEntity<>(companyDTO,HttpStatus.CREATED);
    }


    @GetMapping("/company/all")
    @ResponseBody
    public ResponseEntity<List<CompanyDTO>> getCompany(){
      List<Company> companies = companyService.getAllCompany();
      List<CompanyDTO> companyDTOList = companyService.convertCompanyToDTO(companies);
        return new ResponseEntity<>(companyDTOList, HttpStatus.ACCEPTED);

    }

    @GetMapping("/company/{id}")
    public ResponseEntity<Company> getComapny(@PathVariable("id")  Integer id){
      Company company= companyService.getCompanyById(id);
      return new ResponseEntity<>(company,HttpStatus.OK);

    }

    @PutMapping("/company/update")
    public ResponseEntity<Company> UpdateCompany(@RequestBody Company company){
        
      Company savedCompany=  companyService.addCompany(company);
        return new ResponseEntity<>(savedCompany,HttpStatus.OK);
  
    }
    
    @DeleteMapping("/company/{id}/delete")
    public  ResponseEntity<String> deleteCompany(@PathVariable("id") Integer id){
        companyService.deleteCompanyById(id);

        return new ResponseEntity<>("Company" + id + "delete",HttpStatus.OK);
    }
      
    
  
      }

