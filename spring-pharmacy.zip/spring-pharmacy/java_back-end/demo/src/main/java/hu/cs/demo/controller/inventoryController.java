package hu.cs.demo.controller;

import java.util.List;

import hu.cs.demo.dto.inventoryDTO;
import hu.cs.demo.model.Inventory;
import hu.cs.demo.services.inventoryService;
// import hu.cs.demo.services.stockServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * InventoryController
 */


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class inventoryController {

   @Autowired
   private inventoryService inventoryservice;

   // @Autowired
   // private stockServices stockservices;


   @GetMapping(path = "/inventory/all")
   public ResponseEntity<List<inventoryDTO>> getinventorys(){

      List<Inventory> inventory = inventoryservice.getAllInventory();
      List<inventoryDTO> inventoryDTOList = inventoryservice.convertInventoryToDTO(inventory);
      // List<Inventory> invent = inventoryservice.getAllInventory();
      return new ResponseEntity<>(inventoryDTOList, HttpStatus.OK);
   }

   @PostMapping("/inventory/add")
   public ResponseEntity<inventoryDTO> addInventory(@RequestBody Inventory inventory) {

      // inventory.setStock(stockservices.getById(1));
     Inventory savedInventory = inventoryservice.addInventory(inventory);
      inventoryDTO InventoryDTO = inventoryservice.convertInventoryToDTO(savedInventory);
      return new ResponseEntity<>(InventoryDTO, HttpStatus.CREATED);
   }

   @GetMapping("/inventory/{id}")
   public ResponseEntity<Inventory> getInventory(@PathVariable("id") Integer id) {

      Inventory inventory = inventoryservice.getInventoryById(id);

      return new ResponseEntity<>(inventory, HttpStatus.OK);
   }

   @PutMapping("/inventory/update")
   public ResponseEntity<Inventory> updateInventory(@RequestBody Inventory inventory) {

      Inventory savedInventory = inventoryservice.addInventory(inventory);
 
       return new ResponseEntity<>(savedInventory, HttpStatus.OK);
    }

    @DeleteMapping("/inventory/{id}/delete")
    public ResponseEntity<String> deleteInventory(@PathVariable("id") Integer id) {

      inventoryservice.deleteInventoryById(id);

      return new ResponseEntity<>("Inventory " + id + " deleted !", HttpStatus.OK);
    }
}