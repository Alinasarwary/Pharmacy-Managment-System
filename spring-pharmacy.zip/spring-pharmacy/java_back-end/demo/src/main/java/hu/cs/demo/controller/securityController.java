package hu.cs.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.demo.model.JwtRequest;
import hu.cs.demo.model.JwtResponse;
import hu.cs.demo.model.User;
import hu.cs.demo.repository.UserRepository;
import hu.cs.demo.util.JwtUtility;

@RestController
public class securityController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtility jwtUtility;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    @Qualifier("userDetailsServiceImpl")
    private UserDetailsService userDetailsService;

    @Autowired
    private BCryptPasswordEncoder bcryptPasswordEncoder;


    
    @PostMapping("/api/authenticate")
    public JwtResponse authenticate(@RequestBody JwtRequest jwtRequest) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(),
            jwtRequest.getPassword()));
        } catch (BadCredentialsException e) {
            throw new Exception("Bad Credentials");
        }
        
        UserDetails userDetails = userDetailsService.loadUserByUsername(jwtRequest.getUsername());
        String jwtToken = jwtUtility.generateToken(userDetails);

        User user = userRepository.findByUsername(jwtRequest.getUsername());
        return new JwtResponse(user.getFullname(), user.getUsername(), jwtToken);
      
    }

    @PostMapping("/api/register")
    public JwtResponse register(@RequestBody User user){
        user.setUserpassword(bcryptPasswordEncoder.encode(user.getUserpassword()));
        userRepository.save(user);

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getUsername());
        String jwtToken = jwtUtility.generateToken(userDetails);

        return new JwtResponse(user.getFullname(), user.getUsername(), jwtToken);
    }
    
}
