package hu.cs.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.demo.dto.StockDTO;
import hu.cs.demo.model.Stock;
// import hu.cs.demo.services.CompanyService;
import hu.cs.demo.services.stockServices;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class stockController {
    @Autowired
    private stockServices stockservices;

    // @Autowired
    // private CompanyService companyService;


      @GetMapping("/stock/all")
      public ResponseEntity<List<StockDTO>> getAllStocks(){
        
        List<Stock> stocks = stockservices.getAllStock();
        List<StockDTO> stockDTOList = stockservices.convertToDTO(stocks);
          return new ResponseEntity<>(stockDTOList, HttpStatus.ACCEPTED);
      }

      @PostMapping("/stock/add")
      public ResponseEntity<StockDTO> addStock(@RequestBody Stock stock){
        
        // stock.setCompany(companyService.getCompanyById(2));
        Stock savedStock=  stockservices.addStock(stock);
        StockDTO stockDTO = stockservices.convertToDTO(savedStock);
          return new ResponseEntity<>(stockDTO,HttpStatus.CREATED);
      }

      @GetMapping("/stock/{id}")
    public ResponseEntity<Stock> getStock(@PathVariable("id")  Integer id){
      Stock stock= stockservices.getStockById(id);
      return new ResponseEntity<>(stock,HttpStatus.OK);

    }

    @PutMapping("/stock/update")
    public ResponseEntity<Stock> UpdateStock(@RequestBody Stock stock){
        
      Stock savedStock=  stockservices.addStock(stock);
        return new ResponseEntity<>(savedStock,HttpStatus.OK);
  
    }
    
    @DeleteMapping("/stock/{id}/delete")
    public  ResponseEntity<String> deleteStock(@PathVariable("id") Integer id){
        stockservices.deleteStockById(id);

        return new ResponseEntity<>("Stock" + id + "delete",HttpStatus.OK);
    }
}
