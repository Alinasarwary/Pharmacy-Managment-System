package hu.cs.demo.dto;

// import java.util.List;

public class CompanyDTO {
    private Integer companyId;
    private String companyName;
    private String companyType;
    private String companyDescription;
    private String companyAddress;

    // private Integer stockId;
    // private List<Integer> medicineId;

    // public List<Integer> getMedicineId() {
    //     return medicineId;
    // }

    // public void setMedicineId(List<Integer> medicineId) {
    //     this.medicineId = medicineId;
    // }
    
    // public Integer getStockId() {
    //     return stockId;
    // }

    // public void setStockId(Integer stockId) {
    //     this.stockId = stockId;
    // }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    public String getCompanyDescription() {
        return companyDescription;
    }

    public void setCompanyDescription(String companyDescription) {
        this.companyDescription = companyDescription;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    


}
