package hu.cs.demo.dto;

// import java.util.List;

public class MedicineDTO {
    private Integer medicineId;
    private String medicineName;
    private String medicineCompany;
    private Double medicineCost;
    private String medicineType;
    private String medicineComposition;
    private String medicineDescription;

    // private List<Integer> companyId;
    // public List<Integer> getCompanyId() {
    //     return companyId;
    // }

    // public void setCompanyId(List<Integer> companyId) {
    //     this.companyId = companyId;
    // }
    
    public Integer getMedicineId() {
        return medicineId;
    }

    public void setMedicineId(Integer medicineId) {
        this.medicineId = medicineId;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public String getMedicineCompany() {
        return medicineCompany;
    }

    public void setMedicineCompany(String medicineCompany) {
        this.medicineCompany = medicineCompany;
    }

    public Double getMedicineCost() {
        return medicineCost;
    }

    public void setMedicineCost(Double medicineCost) {
        this.medicineCost = medicineCost;
    }

    public String getMedicineType() {
        return medicineType;
    }

    public void setMedicineType(String medicineType) {
        this.medicineType = medicineType;
    }

    public String getMedicineComposition() {
        return medicineComposition;
    }

    public void setMedicineComposition(String medicineComposition) {
        this.medicineComposition = medicineComposition;
    }

    public String getMedicineDescription() {
        return medicineDescription;
    }

    public void setMedicineDescription(String medicineDescription) {
        this.medicineDescription = medicineDescription;
    }


}
