package hu.cs.demo.dto;


public class StockDTO {
    private Integer stockId;
    private Integer number;
    private String items;
    private String type;
    private String description;

    // private Integer companyId;
    // public Integer getCompanyId() {
    //     return companyId;
    // }

    // public void setCompanyId(Integer companyId) {
    //     this.companyId = companyId;
    // }

    public Integer getStockId() {
        return stockId;
    }

    public void setStockId(Integer stockId) {
        this.stockId = stockId;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getItems() {
        return items;
    }

    public void setItems(String items) {
        this.items = items;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    

 
    
    
    
}
