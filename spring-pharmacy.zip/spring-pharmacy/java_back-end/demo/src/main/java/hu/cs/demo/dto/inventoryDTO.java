package hu.cs.demo.dto;

public class inventoryDTO {

   private Integer inventoryId;
   private String type;
   private String item;
   private Integer number;
   private String description;

//    private Integer stockId;

//    public Integer getStockId() {
//     return stockId;
//     }

//     public void setStockId(Integer stockId) {
//         this.stockId = stockId;
//     }

   public Integer getInventoryId() {
       return inventoryId;
   }

   public void setInventoryId(Integer inventoryId) {
       this.inventoryId = inventoryId;
   }

   public String getType() {
       return type;
   }

   public void setType(String type) {
       this.type = type;
   }

   public String getItem() {
       return item;
   }

   public void setItem(String item) {
       this.item = item;
   }

   public Integer getNumber() {
       return number;
   }

   public void setNumber(Integer number) {
       this.number = number;
   }


   public String getDescription() {
       return description;
   }

   public void setDescription(String description) {
       this.description = description;
   }

  
    
}
