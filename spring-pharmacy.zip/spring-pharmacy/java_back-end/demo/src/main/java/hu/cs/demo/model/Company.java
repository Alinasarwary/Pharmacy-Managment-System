package hu.cs.demo.model;

// import java.util.Set;

// import javax.persistence.CascadeType;
// import javax.persistence.CollectionTable;
// import javax.persistence.ElementCollection;
import javax.persistence.Entity;
// import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
// import javax.persistence.JoinColumn;
// import javax.persistence.ManyToMany;
// import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Companies")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class Company {

    private Integer companyId;
    private String companyName;
    private String companyType;
    private String companyDescription;

	//address is Multivalue 
    // private Set<Address> address;
	// @ElementCollection
	// @CollectionTable(name = "Addresses", joinColumns = @JoinColumn(name = "C_id"))
	// public Set<Address> getAddress() {
	// 	return address;
	// }

	// public void setAddress(Set<Address> address) {
	// 	this.address = address;
	// }

	// private Stock stock;
	// @OneToOne
	// public Stock getStock() {
	// 	return stock;
	// }
	
	// public void setStock(Stock stock) {
	// 	this.stock = stock;
	// }

    // private Set<Medicine> medicine;
    // @ManyToMany(mappedBy = "company", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    // public Set<Medicine> getMedicine() {
    //     return medicine;
    // }

    // public void setMedicine(Set<Medicine> medicine) {
    //     this.medicine = medicine;
    // }
// -----------------------------------------------------------------------------

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getCompanyDescription() {
		return companyDescription;
	}
	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	public Company() {
	}

	public Company(Integer companyId, String companyName, String companyType, String companyDescription) {
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyType = companyType;
		this.companyDescription = companyDescription;
	}

	
  
}
