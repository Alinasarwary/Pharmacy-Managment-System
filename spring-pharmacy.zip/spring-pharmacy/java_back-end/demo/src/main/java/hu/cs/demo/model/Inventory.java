package hu.cs.demo.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 * Inventory
 */
@Entity 
@Table(name = "inventory")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class Inventory {

   
   private Integer inventoryId;
   private String type;
   private String item;
   private Integer number;
   private String description;


   // private Stock stock;
   // @ManyToOne
   // public Stock getStock() {
   //    return stock;
   // }

   // public void setStock(Stock stock) {
   //    this.stock = stock;
   // }

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   public Integer getInventoryId() {
      return inventoryId;
   }
   public void setInventoryId(Integer inventoryId) {
      this.inventoryId = inventoryId;
   }
   public String getType() {
      return type;
   }
   public void setType(String type) {
      this.type = type;
   }
   public String getItem() {
      return item;
   }
   public void setItem(String item) {
      this.item = item;
   }
   public Integer getNumber() {
      return number;
   }
   public void setNumber(Integer number) {
      this.number = number;
   }
   public String getDescription() {
      return description;
   }
   public void setDescription(String description) {
      this.description = description;
   }
   public Inventory() {
   }
   public Inventory(Integer inventoryId, String type, String item, Integer number,
         String description) {
      this.inventoryId = inventoryId;
      this.type = type;
      this.item = item;
      this.number = number;
      this.description = description;
   }

   

   

   
}