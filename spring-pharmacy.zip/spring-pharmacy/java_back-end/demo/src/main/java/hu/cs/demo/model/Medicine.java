package hu.cs.demo.model;

// import java.util.Set;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
// import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name ="Medicines")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class Medicine {

    private Integer medicineId;
    private String medicineName;
    private String medicineCompany;
    private Double medicineCost;
    private String medicineType;
    private String medicineComposition;
    private String medicineDescription;

	
    // private Set<Company> company;
    // @ManyToMany
    // public Set<Company> getCompany() {
    //     return company;
    // }

    // public void setCompany(Set<Company> company) {
    //     this.company = company;
    // }

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(Integer medicineId) {
		this.medicineId = medicineId;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getMedicineCompany() {
		return medicineCompany;
	}
	public void setMedicineCompany(String medicineCompany) {
		this.medicineCompany = medicineCompany;
	}
	public Double getMedicineCost() {
		return medicineCost;
	}
	public void setMedicineCost(Double medicineCost) {
		this.medicineCost = medicineCost;
	}
	public String getMedicineType() {
		return medicineType;
	}
	public void setMedicineType(String medicineType) {
		this.medicineType = medicineType;
	}
	public String getMedicineComposition() {
		return medicineComposition;
	}
	public void setMedicineComposition(String medicineComposition) {
		this.medicineComposition = medicineComposition;
	}
	public String getMedicineDescription() {
		return medicineDescription;
	}
	public void setMedicineDescription(String medicineDescription) {
		this.medicineDescription = medicineDescription;
	}

    public Medicine() {
    }

    public Medicine(Integer medicineId, String medicineName, String medicineCompany, Double medicineCost,
            String medicineType, String medicineComposition, String medicineDescription) {
        this.medicineId = medicineId;
        this.medicineName = medicineName;
        this.medicineCompany = medicineCompany;
        this.medicineCost = medicineCost;
        this.medicineType = medicineType;
        this.medicineComposition = medicineComposition;
        this.medicineDescription = medicineDescription;
    }



    

    

   
}
    