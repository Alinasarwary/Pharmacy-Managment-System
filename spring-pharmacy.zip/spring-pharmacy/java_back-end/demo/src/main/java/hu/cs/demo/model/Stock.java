package hu.cs.demo.model;

// import java.util.Set;

// import javax.persistence.CascadeType;
import javax.persistence.Entity;
// import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
// import javax.persistence.OneToMany;
// import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity 
@Table(name = "stocks")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class Stock {
    
   private Integer stockId;
   private Integer number;
   private String items;
   private String type;
   private String description;
   
//    private Company company;
//    @OneToOne
//    public Company getCompany() {
// 	return company;
// 	}

// 	public void setCompany(Company company) {
// 		this.company = company;
// 	}


	// private Set<Inventory> inventory;
	// @OneToMany(mappedBy = "stock", cascade = CascadeType.ALL, fetch = FetchType.LAZY )
	// public Set<Inventory> getInventory() {
	// 	return inventory;
	// }

	// public void setInventory(Set<Inventory> inventory) {
	// 	this.inventory = inventory;
	// }

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getStockId() {
		return stockId;
	}

	public void setStockId(Integer stockId) {
		this.stockId = stockId;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getItems() {
		return items;
	}

	public void setItems(String items) {
		this.items = items;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Stock() {
	}

	public Stock(Integer stockId, Integer number, String items, String type, String description) {
		this.stockId = stockId;
		this.number = number;
		this.items = items;
		this.type = type;
		this.description = description;
	}





   

   

}