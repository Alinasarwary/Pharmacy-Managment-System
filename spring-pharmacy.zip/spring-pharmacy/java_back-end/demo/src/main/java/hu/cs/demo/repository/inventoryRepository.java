package hu.cs.demo.repository;

import hu.cs.demo.model.Inventory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * inventoryRepository
 */

 @Repository
public interface inventoryRepository extends JpaRepository<Inventory, Integer>{

   
}