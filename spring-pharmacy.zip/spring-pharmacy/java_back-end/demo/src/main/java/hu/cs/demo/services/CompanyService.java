package hu.cs.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import hu.cs.demo.dto.CompanyDTO;
import hu.cs.demo.model.Company;

@Service
public interface CompanyService {
    Company addCompany(Company company);

	List<Company> getAllCompany();

    Company getCompanyById(Integer id);

	void deleteCompanyById(Integer id);

	Company getById(Integer id);

	List<CompanyDTO> convertCompanyToDTO(List<Company> companies);
	CompanyDTO convertCompanyToDTO(Company companies);

}
 