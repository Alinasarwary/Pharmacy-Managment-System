package hu.cs.demo.services;

import java.util.ArrayList;
import java.util.List;
// import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cs.demo.dto.CompanyDTO;
import hu.cs.demo.model.Company;
import hu.cs.demo.repository.CompanyRepository;

@Service
public class CompanyServiceImpl implements CompanyService {
    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Company addCompany(Company company) {

        return companyRepository.save(company);
    }

    @Override
    public List<Company> getAllCompany() {

        return companyRepository.findAll();
    }

    @Override
    public Company getCompanyById(Integer id) {

        return companyRepository.getOne(id);
    }

    @Override
    public void deleteCompanyById(Integer id) {
        companyRepository.deleteById(id);

    }

    @Override
    public Company getById(Integer id) {
        return companyRepository.getOne(id);
    }

    @Override
    public List<CompanyDTO> convertCompanyToDTO(List<Company> companies) {
        List<CompanyDTO> companyDTOList = new ArrayList<>();
        for(Company company : companies){
            CompanyDTO companyDTO = modelMapper.map(company, CompanyDTO.class);
            // companyDTO.setMedicineId(company.getMedicine().stream().map(mapper -> mapper.getMedicineId()).collect(Collectors.toList()));
            companyDTOList.add(companyDTO);
        }
        return companyDTOList;
    }

    @Override
    public CompanyDTO convertCompanyToDTO(Company companies) {
        CompanyDTO companyDTO = modelMapper.map(companies, CompanyDTO.class);

        return companyDTO;
    }

}
