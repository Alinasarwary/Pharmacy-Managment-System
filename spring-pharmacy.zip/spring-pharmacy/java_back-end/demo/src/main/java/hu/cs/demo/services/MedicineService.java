package hu.cs.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import hu.cs.demo.dto.MedicineDTO;
import hu.cs.demo.model.Medicine;

@Service
public interface MedicineService {
    Medicine addMedicine(Medicine medicine);

	List<Medicine> getAllMedicine();

    Medicine getMedicineById(Integer id);

	void deleteMedicineById(Integer id);

	List<MedicineDTO> ConvertMedicineToDTO(List<Medicine> medicines);
	MedicineDTO ConvertMedicineToDTO(Medicine medicines);
}
 