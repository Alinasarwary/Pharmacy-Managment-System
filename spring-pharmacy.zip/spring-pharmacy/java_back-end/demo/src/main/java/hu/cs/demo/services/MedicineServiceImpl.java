package hu.cs.demo.services;

import java.util.ArrayList;
import java.util.List;
// import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cs.demo.dto.MedicineDTO;
import hu.cs.demo.model.Medicine;
import hu.cs.demo.repository.medicineRepository;

@Service
public class MedicineServiceImpl implements MedicineService {

    @Autowired
    private medicineRepository medicinerepository;

    @Autowired
    private  ModelMapper modelMapper;

    @Override
    public Medicine addMedicine(Medicine medicine) {

        return medicinerepository.save(medicine);
    }

    @Override
    public List<Medicine> getAllMedicine() {

        return medicinerepository.findAll();
    }

    @Override
    public Medicine getMedicineById(Integer id) {

        return medicinerepository.getOne(id);
    }

    @Override
    public void deleteMedicineById(Integer id) {
        medicinerepository.deleteById(id);

    }

    @Override
    public List<MedicineDTO> ConvertMedicineToDTO(List<Medicine> medicines) {
        List<MedicineDTO> medicineDTOList = new ArrayList<>();
        for(Medicine medicine : medicines){
            MedicineDTO medicineDTO = modelMapper.map(medicine, MedicineDTO.class);
            // medicineDTO.setCompanyId(medicine.getCompany().stream().map(mapper -> mapper.getCompanyId()).collect(Collectors.toList()));
            medicineDTOList.add(medicineDTO);
        }
        return medicineDTOList;
    }

    @Override
    public MedicineDTO ConvertMedicineToDTO(Medicine medicines) {
        
        return null;
    }
    
}
