package hu.cs.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import hu.cs.demo.dto.inventoryDTO;
import hu.cs.demo.model.Inventory;

/**
 * InventoryService
 */

@Service
public interface inventoryService {

   Inventory addInventory(Inventory inventory);

   List<Inventory> getAllInventory();

   Inventory getInventoryById(Integer id);

   void deleteInventoryById(Integer id);

   List<inventoryDTO> convertInventoryToDTO(List<Inventory> inventory);
   inventoryDTO convertInventoryToDTO(Inventory inventory);
}