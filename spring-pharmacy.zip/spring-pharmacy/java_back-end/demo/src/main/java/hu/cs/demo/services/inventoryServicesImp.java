package hu.cs.demo.services;

import java.util.ArrayList;
import java.util.List;

import hu.cs.demo.dto.inventoryDTO;
import hu.cs.demo.model.Inventory;
import hu.cs.demo.repository.inventoryRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * InventoryServiceImpl
 */
@Service
public class inventoryServicesImp implements inventoryService {

   @Autowired
   private inventoryRepository inventoryrepository;

   @Autowired
   private ModelMapper modelMapper;

   @Override
   public Inventory addInventory(Inventory inventory) {
      return inventoryrepository.save(inventory);
   }

   @Override
   public List<Inventory> getAllInventory() {
      return inventoryrepository.findAll();
   }

   @Override
   public Inventory getInventoryById(Integer id) {
      return inventoryrepository.getOne(id);
   }

   @Override
   public void deleteInventoryById(Integer id) {
      inventoryrepository.deleteById(id);
   }

   @Override
   public List<inventoryDTO> convertInventoryToDTO(List<Inventory> inventory) {
      List<inventoryDTO> inventoryDTOList = new ArrayList<>();
      for(Inventory invent : inventory){
         inventoryDTO InventoryDTO = modelMapper.map(invent, inventoryDTO.class);
         inventoryDTOList.add(InventoryDTO);
      }
      return inventoryDTOList;
   }

   @Override
   public inventoryDTO convertInventoryToDTO(Inventory inventory) {
      inventoryDTO InventoryDTO = modelMapper.map(inventory, inventoryDTO.class);
      return InventoryDTO;
   }
   
}