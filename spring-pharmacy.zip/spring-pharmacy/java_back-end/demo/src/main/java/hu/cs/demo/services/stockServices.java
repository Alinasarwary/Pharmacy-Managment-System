package hu.cs.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import hu.cs.demo.dto.StockDTO;
import hu.cs.demo.model.Stock;

@Service
public interface stockServices {

	Stock addStock(Stock stock);

	List<Stock> getAllStock();

	Stock getStockById(Integer id);

	void deleteStockById(Integer id);

	Stock getById(Integer id);

	List<StockDTO> convertToDTO(List<Stock> stocks);
	StockDTO convertToDTO(Stock stock);

	
}
