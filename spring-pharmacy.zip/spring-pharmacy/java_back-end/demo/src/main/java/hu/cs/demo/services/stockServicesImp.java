package hu.cs.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cs.demo.dto.StockDTO;
import hu.cs.demo.model.Stock;
import hu.cs.demo.repository.stockRepository;

@Service
public class stockServicesImp implements stockServices {

    @Autowired
    private stockRepository stockrepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Stock addStock(Stock stock) {
        return stockrepository.save(stock);
    }

    @Override
    public List<Stock> getAllStock() {
        return stockrepository.findAll();
    }

    @Override
    public Stock getStockById(Integer id) {

        return stockrepository.getOne(id);
    }

    @Override
    public void deleteStockById(Integer id) {
        stockrepository.deleteById(id);

    }

    @Override
    public Stock getById(Integer id) {
        return stockrepository.getOne(id);
    }

    @Override
    public List<StockDTO> convertToDTO(List<Stock> stocks) {
        List<StockDTO> stockDTOList = new ArrayList<>();
        for(Stock stock: stocks){
            StockDTO stockDTO = modelMapper.map(stock, StockDTO.class);
            stockDTOList.add(stockDTO);
          }
        return stockDTOList;
    }

    @Override
    public StockDTO convertToDTO(Stock stock) {
        StockDTO stockDTO = modelMapper.map(stock, StockDTO.class);

        return stockDTO;
    }


    
}
