<template>
  <div>
    <template v-if="!$route.meta.allowAnonymous">
      <v-app id="inspire" >
        <div class="app-container">
          <toolbar @toggleNavigationBar="drawer = !drawer"/>
          <navigation :toggle="drawer"/>
          <v-content>
            <breadcrumbs />
            <router-view/>
          </v-content>
        </div>
      </v-app>
    </template>
    <template v-else>
      <transition>
        <keep-alive>
          <router-view></router-view>
        </keep-alive>
      </transition>
    </template>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      drawer: true
    }
  },
  methods:{
    logout() {
      this.$store.dispatch("logout");
    }
  },
  computed:{
    loggedIn() {
      return this.$store.getters.loggedIn;
    }
  }
}
</script>

<style>
  .v-btn:hover:before{
    color: transparent !important;
  }
  
</style>
