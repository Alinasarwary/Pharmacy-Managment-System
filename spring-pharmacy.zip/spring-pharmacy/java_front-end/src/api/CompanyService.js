import axiosClient from "./axiosClient";

export default {
  addCompany(company) {
    return axiosClient.post("/company/add", company);
  },
  getComapny() {
    return axiosClient.get("/company/all");
  },
  deleteCompany(companyId) {
    return axiosClient.delete(`/company/${companyId}/delete`);
  },
  getCompany(companyId) {
    return axiosClient.get(`/company/${companyId}`)
  },
  UpdateCompany(company) {
    return axiosClient.put("/company/update", company);
  }
};