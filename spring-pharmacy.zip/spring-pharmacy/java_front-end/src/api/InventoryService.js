import axiosClient from "./axiosClient";

export default {
  addInventory(inventory) {
    return axiosClient.post("/inventory/add", inventory);
  },
  getinventorys() {
    return axiosClient.get("/inventory/all");
  },
  deleteInventory(inventoryId) {
    return axiosClient.delete(`/inventory/${inventoryId}/delete`);
  },
  getInventory(inventoryId) {
    return axiosClient.get(`/inventory/${inventoryId}`);
  },
  updateInventory(inventory) {
    return axiosClient.put("/inventory/update", inventory);
  }
};
