import axiosClient from "./axiosClient";
export default {
  addMedicine(medicine) {
    return axiosClient.post("/medicine/add", medicine);
  },
  getMedicine() {
    return axiosClient.get("/medicine/all");
  },
  deleteMedicine(medicineId) {
    return axiosClient.delete(`/medicine/${medicineId}/delete`);
  },
  getMedicine(medicineId) {
    return axiosClient.get(`/medicine/${medicineId}`)
  },
  UpdateMedicine(medicine) {
    return axiosClient.put("/medicine/update", medicine);
  }
};

