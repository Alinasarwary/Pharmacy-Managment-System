import axiosClient from "./axiosClient";
export default {
  addStock(stock) {
    return axiosClient.post("/stock/add", stock);
  },
  getAllStocks() {
    return axiosClient.get("/stock/all");
  },
  deleteStock(stockId) {
    return axiosClient.delete(`/stock/${stockId}/delete`);
  },
  getStock(stockId) {
    return axiosClient.get(`/stock/${stockId}`)
  },
  updateStock(stock) {
    return axiosClient.put("/stock/update", stock);
  }
};

