import axios from "axios";
import Vue from "vue";
const axiosClient = axios.create({
    baseURL: "/api"
});

export default axiosClient;