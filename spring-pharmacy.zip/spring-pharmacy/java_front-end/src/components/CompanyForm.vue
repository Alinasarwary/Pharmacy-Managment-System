<template>
<v-stepper>
     <v-layout row>
      <v-flex d-flex lg6 class="mx-auto">
        <v-form ref="form" v-model="valid" class="pt-4">
              <v-text-field
                v-model="companyName"
                label="Company Name"
                required
              ></v-text-field>
          

              <v-select
                v-model="type"
                :items="items"
                :rules="[v => !!v || 'please select your favorites']"
                label="Type"
                required />
            
                <v-text-field
                v-model="description"
                label="Description"
                :rules="[v => !!v || 'input must not empty']"
                required
                />
                <v-text-field
                v-model="address"
                label="Address"
                :rules="[v => !!v || 'input must not empty']"
                required
                />

            <v-checkbox 
              v-model="checkbox"
              :rules="[v => !!v || 'Are you sure to save?']"
              label="Are you sure to save?"
              required
              />

            <v-btn v-if="companyId" color="primary" @click="updateCompany" class="mb-5">update</v-btn>
            <v-btn v-else color="black" @click="saveCompany" class="mb-5 white--text">save</v-btn>
            <v-btn @click.native="clear" class="mb-5">clear</v-btn>
          </v-form>
        </v-flex>
     </v-layout>
</v-stepper>
</template>



<script>
import companyService from "../api/CompanyService";
import{eventBus} from "../main";

export default {
  props: ["companyId"],
  data() {
    return {
      step: 0,
      valid: true,
      companyName: null,
      type: null,
      description: null,
      address:null,

      items: ["Local", "Global"],
      checkbox: false,
      snackbar:false
      
    };
  },
  methods: {
    async saveCompany() {
      const company = {
        companyName: this.companyName,
        description: this.description,
        type: this.type,
        address:this.address
      };
      const savedcompany = await companyService.addCompany(company);
      console.log(savedcompany);
      eventBus.$emit("companySaved",true)
      this.snackbar = true;
      setTimeout(() => {
        this.$router.push("/company/all");
      }, 2000);
      
    },
   async updateCompany() {
      const company = {
        _id: this.companyId,
        companyName: this.companyName,
        description: this.description,
        type: this.type,
        address:this.address
      };
    const response= await companyService.UpdateCompany(company);
    const updatecompany=response.data;
    eventBus.$emit("companySaved",true)
    setTimeout(()=>{
            this.$router.push("/company/all")
      },2000)
    // this.snackbar=true;
    console.log(updatecompany);
    
    },
    
    clear () {
       this.$refs.form.reset()
      }
  },
  async created() {
    if (this.companyId) {
      const response = await companyService.addCompany(this.companyId);
      const company = response.data;
      this.companyName = company.companyName;
      this.description = company.description;
      this.type = company.type;
      this.address= company.address;
    }
  }
};
</script>
<style scoped>
</style>
