<template>
<v-stepper>
     <v-layout row>
      <v-flex d-flex lg6 class="mx-auto" >
        <v-form ref="form" v-model="valid" class="pt-4">

              <v-select
              v-model="item"
              :items="items"
              label=" Item"
              regular
              ></v-select>
          
              <v-select
              v-model="type"
              :items="types"
              label=" Type"
              regular
              ></v-select>

              <v-text-field
              v-model="number"
              label=" Number"
              regular
              ></v-text-field>

  
              <v-text-field
              v-model="inventory_name"
              label=" Name"
              regular
              ></v-text-field>

              <v-text-field
              v-model="description"
              label=" Description"
              regular
              ></v-text-field>


            <div class="mx-3 mt-4">
              <v-btn small v-if="inventoryId" color="primary" @click="updateInventory" class="mb-5">update</v-btn>
              <v-btn small v-else color="black" @click="saveInventory" class="mb-5 white--text">save</v-btn>
              <v-btn small @click.native="clear" class="mb-5">clear</v-btn>
            </div>
          </v-form>
        </v-flex>
     </v-layout>
</v-stepper>
</template>

<script>
import InventoryService from "../api/InventoryService";
export default {
  props: ["inventoryId"],
  data() {
    return {
      term: null,
      item: null,
      type: null,
      number: null,
      inventory_name: null,
      description: null,
      items: ["Antibiotics", "Strengthen"],
      types: ["Tablet", "Sharbat", "Ampol"]
    };
  },

  methods: {
    async saveInventory() {
      const inventory = {
        term: this.term,
        item: this.item,
        type: this.type,
        number: this.number,
        inventory_name: this.inventory_name,
        description: this.description
      };
      const saveInventory = await InventoryService.addInventory(inventory);
      console.log(saveInventory);
      this.resetForm();
    },
    resetForm() {
      (this.item = null),
        (this.term = null),
        (this.type = null),
        (this.number = null),
        (this.inventory_name = null),
        (this.description = null);
    },
    async updateInventory() {
      const inventory = {
        id: this.inventoryId,
        term: this.term,
        item: this.item,
        type: this.type,
        number: this.number,
        inventory_name: this.inventory_name,
        description: this.description
      };
      const response = await InventoryService.updateInventory(inventory);
      const updatingInventory = response.data;
      this.$router.push("/inventory/all");
      console.log(updatingInventory);
    }
  },
  async created() {
    if (this.inventoryId) {
      const response = await InventoryService.getById(this.inventoryId);
      const inventory = response.data;
      (this.item = inventory.item),
        (this.term = inventory.term),
        (this.type = inventory.type),
        (this.number = inventory.number),
        (this.inventory_name = inventory.inventory_name),
        (this.description = inventory.description);
    }
  }
};
</script>