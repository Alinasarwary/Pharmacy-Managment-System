<template>
<v-stepper>
     <v-layout row>
      <v-flex d-flex lg6 class="mx-auto" >
        <v-form ref="form" v-model="valid" class="pt-4">

              <v-text-field
                v-model="medicineName"
                label="Name"
                required
              ></v-text-field>
          
              <v-select
                v-model="medicineCompany"
                :items="items"
                label="Company"
                required />

              <v-text-field
                v-model="medicineComposition"
                label="Composition"
                required
              ></v-text-field>

  
              <v-text-field
                v-model="medicineType"
                label="MedicineType"
                required
              ></v-text-field>

              <v-text-field
                v-model="medicineCost"
                label="Cost"
                required
              ></v-text-field>
              

              <v-text-field
                v-model="medicineDescription"
                label="Description"
                required
              ></v-text-field>



            <div class="mx-3 mt-4">
              <v-btn small v-if="medicineId" color="primary" @click="updateMedicine" class="mb-5">update</v-btn>
              <v-btn small v-else color="black" @click="saveMedicine" class="mb-5 white--text">save</v-btn>
              <v-btn small @click.native="clear" class="mb-5">clear</v-btn>
            </div>
          </v-form>
        </v-flex>
     </v-layout>
</v-stepper>
</template>

<script>
import MedicineService from "../api/MedicineService";
export default {
  props: ["medicineId"],
  data(){
    return {
      valid:true,
      medicineName : null,
      medicineCompany : null,
      medicineCost: null,
      medicineType : null,
      medicineComposition:null,
      medicineDescription:null,
      snackbar: false,
      
      
    };
  },
  computed: {
    text(){
      return this.medicineId ? "Medicine updated successfully" : "medicine saved successfully";
    }
  },

  methods: {
    async saveMedicine(){
      const medicine = {
        medicineName: this .medicineName,
        medicineCompany: this.medicineCompany,
        medicineCost: this.medicineCost,
        medicineType: this.medicineType,
        medicineComposition: this.medicineComposition,
        medicineDescription:this.medicineDescription,
        
      }

      const savedMedicine = await MedicineService.addMedicine(medicine);
      console.log(savedMedicine);
      this.resetForm();
      this.snackbar = true;
      // this.$router.push("/medicine/all");
    },
    resetForm(){
      this.medicineName = null;
      this.medicineCompany = null;
      this.medicineCost = null;
      this.medicineType = null;
      this.medicineComposition = null;
      this.medicineDescription = null;
    },
    async updateMedicine(){
      const medicine = {
        _id: this.medicineId,
      medicineName:  this.medicineName,
      medicineCompany: this.medicineCompany,
      medicineCost: this.medicineCost,
      medicineType: this.medicineType,
      medicineComposition: this.medicineComposition,
      medicineDescription: this.medicineDescription
        
      }
      const response = await MedicineService.updateMedicine(medicine);
      const updatingMedicine = response.data;
      this.snackbar = true;
      console.log(updatingMedicine);
    }
  },

  async created(){
    if(this.medicineId){
    const response = await MedicineService.getById(this.medicineId);
    const medicine = response.data;
    this.medicineName = medicine.medicineName;
      this.medicineCompany = medicine.medicineCompany;
      this.medicineCost = medicine.medicineCost;
      this.medicineType = medicine.medicineType;
      this.medicineComposition = medicine.medicineComposition;
      this.medicineDescription = medicine.medicineDescription;
    
    console.log(medicine);
    }
  }
}

</script>
<style scoped>

</style>

