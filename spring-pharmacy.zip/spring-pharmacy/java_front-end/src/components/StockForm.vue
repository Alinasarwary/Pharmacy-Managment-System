<template>
<v-stepper>
     <v-layout row>
      <v-flex d-flex lg6 class="mx-auto" >
        <v-form ref="form" v-model="valid" class="pt-4">
          
              <v-text-field
                v-model="number"
                label="Number"
                required
              ></v-text-field>

              <v-select
                v-model="items"
                :item="item"
                label="Items"
                required />

              <v-text-field
                v-model="type"
                label="Stock Type"
                required
              ></v-text-field>

              <v-text-field
                v-model="description"
                label="Stock Description"
                required
              ></v-text-field>


            <!-- <v-checkbox 
              v-model="checkbox"
              :rules="[v => !!v || 'Are you sure to save?']"
              label="Are you sure to save?"
              required
              /> -->

            <div class="mx-3 mt-4">
              <v-btn small v-if="stockId" color="primary" @click="updateStock" class="mb-5">update</v-btn>
              <v-btn small v-else color="black" @click="saveStock()" class="mb-5 white--text">save</v-btn>
              <v-btn small @click.native="clear" class="mb-5">clear</v-btn>
            </div>
          </v-form>
        </v-flex>
     </v-layout>
</v-stepper>
</template>



<script>
import StockServices from "../api/StockServices";
export default {
  props: ["stockId"],
  components: {},
  data() {
    return {
      valid: true,
      number: null,  
      type: null, 
      items: null,
      item: ["", ""],
      description: null,
      // checkbox: false,
      snackbar:false
    }
  },
  methods: {
    async saveStock() {
        const stock = {
           number: this.number,
           type: this.type,
           items: this.items,
           description: this.description

        }
        console.log(stock);
        const savedStock = await StockServices.addStock(stock);
        console.log(savedStock);
        this.resetForm();
        this.$store.dispatch("updateSnackbar", {
          snackbar: true,
          text: "Stock Details saved successfully",
          timeout: 5000
        });
    },
    resetForm() {
      this.$refs.form.reset();
    },

    async updateStock() {
      const stock = {
        _id: this.stockId,
        number: this.number,
        type: this.type,
        items: this.items,
        description: this.description,
      }
      const response = await StockServices.updateStock(stock);
      const updateStock = response.data;
      this.$store.dispatch("updateSnackbar", {
        snackbar: true,
        text: "Stock Detail updated successfully",
        timeout: 1000
      });
      setTimeout(() => {
        this.$router.push("/stock/all");
      }, 2000);
      console.log(updateStock);
    }
  },
  async created() {
    if (this.stockId) {
      const response = await StockServices.getStock(this.stockId);
      const stock = response.data;
      this.number = stock.number;
      this.type = stock.type;
      this.items = stock.items;
      this.description = stock.description;
    }
  }
};
</script>
<style scoped>
</style>
