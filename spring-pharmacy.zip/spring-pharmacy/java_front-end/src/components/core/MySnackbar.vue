<template>
  <div class="text-center ma-2"> 
        <v-snackbar color="rgb(29, 41, 57)" right
          v-model="snackbar">
          {{ text }}

          <template>
           <v-btn
              color="white"
              flat
              @click="showSnackbar = false">
              Close
            </v-btn>
          </template>
        </v-snackbar>
      </div>
</template>

<script>
import {eventBus} from "../../main";

export default {
    props: ["text"],
    data(){
        return{
            snackbar: false
        }
    },
    
    created(){
        eventBus.$on("saveStaff", (param) => {
            this.snackbar = param;
        }),
        eventBus.$on("foodSaved", (param) => {
          this.snackbar = param;
        })
    }
}
</script>

<style>

</style>