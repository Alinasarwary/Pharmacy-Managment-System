<template>
  <v-navigation-drawer
  v-model="listLocal"
    fixed app>
    <v-toolbar flat dark :color="$root.themeColor" class="toolbar">
      <router-link :to="{ name: 'Home' }">
      </router-link>
      <router-link :to="{ name: 'Home' }">
        <img src="../../images/pharmacy.png" width="36px" />
      </router-link>
      <router-link :to="{ name: 'Home' }" class="text">
         Pharmacy Managment 
      </router-link>
    </v-toolbar>

    <v-list>
      <v-list-tile @click="changeRoute('Home', 1)">
        <v-list-tile-action>
          <img src="../../images/dashboard.svg" width="25px" alt="" class="opacity">
        </v-list-tile-action>
        <v-list-tile-title :class="[{'active': selectedIndex === 1}, 'item-title' ]" >{{ $t('Home') }}</v-list-tile-title>
      </v-list-tile>



    <v-list-group prepend-icon="">
        <v-list-tile slot="activator">    
          <img src="../../images/medicine.svg" alt="" width="25px" class="mr-4 opacity"/>&nbsp;<v-list-tile-title class="item-title"> {{ $t('Mediciens') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('AddMedicine', 4)">
          <v-list-tile-action>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 4}, 'item-title' ]">{{ $t('Add Medicine') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('Medicines', 5)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 5}, 'item-title' ]">{{ $t('Medicines') }}</v-list-tile-title>
        </v-list-tile>
    </v-list-group>
    
    <v-list-group
        >
        <v-list-tile slot="activator">
          <img src="../../images/enterprise.svg" alt="" width="25px" class="mr-4 opacity"><v-list-tile-title class="item-title">{{ $t('Company') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('Add Company', 4)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 4}, 'item-title' ]">{{ $t('Add Company') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('Companies', 5)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 5}, 'item-title' ]">{{ $t('Companies') }}</v-list-tile-title>
        </v-list-tile>
    </v-list-group>
    
     <v-list-group>
        <v-list-tile slot="activator">
          <img src="../../images/inventory-list.svg" width="25px" alt="" class="mr-4 opacity"><v-list-tile-title class="item-title">{{ $t('Inventory') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('Add Inventory', 4)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 4}, 'item-title' ]">{{ $t('Add Inventory') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('Products', 5)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 5}, 'item-title' ]">{{ $t('Products') }}</v-list-tile-title>
        </v-list-tile>
    </v-list-group>

    <v-list-group>
        <v-list-tile slot="activator">
          <img src="../../images/stock.svg" width="25px" alt="" class="mr-4 opacity"><v-list-tile-title class="item-title">{{ $t('Stock') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('AddStock', 6)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 6}, 'item-title' ]">{{ $t('Add to Stock') }}</v-list-tile-title>
        </v-list-tile>
        <v-list-tile @click="changeRoute('Stock Details', 7)">
          <v-list-tile-action>
            <v-icon></v-icon>
          </v-list-tile-action>
          <v-list-tile-title :class="[{'active': selectedIndex === 7}, 'item-title' ]">{{ $t('Stock Details') }}</v-list-tile-title>
        </v-list-tile>
    </v-list-group>

     
    </v-list>
    <v-list>
      <div class="bottom">
          <v-list-group
              prepend-icon="fingerprint">
              <v-list-tile slot="activator">
                <v-list-tile-title class="item-title">{{ $t('authorization') }}</v-list-tile-title>
              </v-list-tile>
              <v-list-tile @click="$router.push({ name: 'Login' })">
                <v-list-tile-action>
                </v-list-tile-action>
                <v-list-tile-title class="item-title">{{ $t('Login') }}</v-list-tile-title>
              </v-list-tile>
              
              <v-list-tile @click="$router.push({ name: 'SignUp' })">
                <v-list-tile-action>
                </v-list-tile-action>
                <v-list-tile-title class="item-title">{{ $t('SignUp') }}</v-list-tile-title>
              </v-list-tile>
          </v-list-group>
            <v-list-tile>
                  <v-list-tile-action >
                    <v-icon v-text="'settings'"></v-icon>
                  </v-list-tile-action>
                  <v-list-tile-title v-text="'Settings'" class="item-title"></v-list-tile-title>
            </v-list-tile>
      </div>
    </v-list>
    
  </v-navigation-drawer>
</template>

<script>
export default {
   props: {
    toggle: {
        type: Boolean,
        required: true,
        default: false
    }
  },
  model:{
    prop: "toggle",
    event:"toggleChange"
  },

  data() {
    return {
      selectedIndex: 1
    }
  },

  methods: {
    changeRoute(routeName, selectedIndex) {
      const vm = this;

      vm.selectedIndex = selectedIndex;

      return vm.$router.push({ name: routeName });
    },
    logout() {
      this.$store.dispatch("logout");
    }
  },
  computed:{
    listLocal:{
      get: function(){
        return this.toggle;
      },
      set: function(value){
        this.$emit("toggleChange", value);
      },
      loggedIn() {
        return this.$store.getter.loggedIn;
      },
      // hide () {
      //   return this.$router.path === '/login' || this.$router.path === '/register'; 
      // }
    }
  }
}
</script>

<style>
  .toolbar {
    font-weight: bold;
    font-size: 18px;
  }

  .toolbar .text {
    padding-left: 15px;
    color: white;
    text-decoration:none;
  }

  .item-title {
    font-size: 17px;
    font-weight: 500;
  }
  .item-sub-title {
    font-size: 15px;
    font-weight: 500;
  }

  .active {
    font-weight: bold;
  }
  .bottom{
    position: absolute;
    bottom: 0;
    left: 0;
    right:0;
  }
  .grayscale { 
    -webkit-filter: grayscale(1);
    filter: grayscale(100%); 
    }

  .opacity{
    opacity: 0.5;
  }
</style>
