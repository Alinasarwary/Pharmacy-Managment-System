<template>
    <v-container>
      <h2 class="text">Add  Company</h2>
        <v-flex d-flex lg10 sm6 class="size">
            <CompanyForm/>
            <MySnackbar text ="Company was added successfully!"/>
        </v-flex>
    </v-container>
</template>

<script>
import CompanyForm from '../../components/CompanyForm';
import MySnackbar from "../../components/core/MySnackbar";

export default {
  components: {
    CompanyForm: CompanyForm,
    MySnackbar: MySnackbar
  }
};
</script>

<style>
.text{
  text-align: center;
}
.size{
  margin-left: 25%;
}
</style>