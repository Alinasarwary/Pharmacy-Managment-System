<template>
  <v-flex d-flex lg12 sm8>
    <div>
    <h1 style="text-align: center">List of Companies</h1><br>
      <template>
        <div align="center">
        <thead>
          <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Company Name</th>
            <th class="text-left">Company Description</th>
            <th class="text-left">Type</th>
            <th class="text-left">Company Address</th>
            <th class="text-left">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="company in companies" :key="company._id">
            <td></td>
            <td>{{company.companyName}}</td>
            <td>{{company.description}}</td>
            <td>{{company.type}}</td>
            <td>{{company.address}}</td>
            <td>
              <v-btn
                :to="{name: 'EditFood', params :{
                id:company._id
              }}"
                small
                color="warning"
                class="mr-2"
              >Edit</v-btn>
              <v-btn small color="primary" @click="deleteCompany(company._id)">Delete</v-btn>
            </td>
          </tr>
        </tbody>
        </div>
        <div class="text-center ma-2">
          <v-snackbar color="primary" right v-model="snackbar">
            {{text}}
            <template>
               <v-btn
              color="white"
              flat
              @click="showSnackbar = false">
              Close
               </v-btn>
            </template>
          </v-snackbar>
        </div>
      </template>
    </div>
  </v-flex>
</template>

<script>
import companyService from "../../api/CompanyService";
export default {
  data() {
    return {
      companies: [],
      snackbar: false,
      text: "Company deleted successfully"
    };
  },
  methods: {
    async deleteCompany(companyId){
      const conf = confirm("Do you really want to delete this company?");
      if(conf){
        const response = await companyService.deleteById(companyId);
        console.log(response.data);

        this.companies = this.companies.filter(company => {
          return company._id !== companyId;
        });
        this.snackbar = true;
      }
    },
  },
  async mounted() {
    const response = await companyService.getAllCompanies();
    this.companies = response.data;
    console.log(response.data);
  }
};
</script>

<style>
</style>