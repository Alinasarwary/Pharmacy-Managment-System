<template>
  <v-container>
      <h2 class="text">Edit Company</h2><br>
      <v-flex d-flex lg10 sm6 class="size">
        <CompanyForm :companyId="companyId"/>
        <MySnackbar text="Company Info modify !"/>
      </v-flex>
  </v-container>
</template>


<script>
import CompanyForm from "../../components/CompanyForm";
import MySnackbar from "../../components/core/MySnackbar";
export default {
  components: {
    CompanyForm: CompanyForm,
    MySnackbar: MySnackbar
  },
  data() {
    return {
      companyId: this.$route.params.id
    };
  }
};
</script>

<style>
.text{
  text-align: center;
}
.size{
  margin-left: 25%;
}
</style>