<template>
  <v-container fluid >
      <h1 class="text">Edit Inventory</h1><br>
      <v-flex d-flex lg10 sm6 class="size">
        <InventoryForm :inventoryId="Id"/>
        <MySnackbar text="inventory Details Modify Successfully!"/>
      </v-flex>
  </v-container>
</template>

<script>
import InventoryForm from "../../components/InventoryForm";

export default {
  components: {
    InventoryForm: InventoryForm
  },
  data() {
    return {
      inventoryId: this.$route.params.id
    };
  }
};
</script>