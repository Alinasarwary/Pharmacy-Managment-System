<template>
  <v-flex d-flex lg12 sm6>
    <div>
    <h1 align="center" class="mb-3">Inventory details</h1>
      <template>
        <div align="center">
        <thead>
          <tr>
            <th class="text-left">Term</th>
            <th class="text-left">Item</th>
            <th class="text-left">Type</th>
            <th class="text-left">Number</th>
            <th class="text-left">Name</th>
            <th class="text-left">Description</th>
            <th class="text-left">Action</th>
          </tr>
        </thead>
        <tbody>
         <tr v-for="inventory in inventories" :key="inventory.id">
            <td>{{ inventory.term }}</td>
            <td>{{ inventory.item }}</td>
            <td>{{ inventory.type }}</td>
            <td>{{ inventory.number }}</td>
            <td>{{ inventory.inventory_name }}</td>
            <td>{{ inventory.description }}</td>
            <td>
              <v-btn
                :to="{name: 'EditInventory', params :{
                id:inventory._id
              }}"
                small
                color="primary"
                class="mr-2"
              >Edit</v-btn>
              <v-btn small color="warning" @click="deleteInventory(inventory._id)">Delete</v-btn>
            </td>
          </tr>
        </tbody>
        </div>
        <div class="text-center ma-2">
          <v-snackbar color="rgb(29, 41, 57)" right v-model="snackbar">
            {{text}}
            <template>
               <v-btn
              color="white"
              flat
              @click="showSnackbar = false">
              Close
               </v-btn>
            </template>
          </v-snackbar>
        </div>
      </template>
    </div>
  </v-flex>
</template>


<script>
import InventoryService from "../../api/InventoryService";
export default {
  data() {
    return {
      inventories: []
    };
  },

  methods: {
    async deleteInventory(inventoryId) {
      const conf = confirm("Do you want to delete this member?");
      if (conf) {
        const response = await InventoryService.deleteInventory(inventoryId);
        console.log(response.data);
        this.inventories = this.inventories.filter(inventory => {
          return inventory.id !== inventoryId;
        });
      }
    }
  },
  async mounted() {
    const response = await InventoryService.getinventorys();
    this.inventories = response.data;
  }
};
</script>
<style scoped>
</style>