<template>
    <v-container class="position">
      <h2 class="text">Add New Inventory</h2>
        <v-flex d-flex lg10 sm6 class="size">
            <InventoryForm/>
            <MySnackbar text ="Inventory is saved successfully!"/>
        </v-flex>
    </v-container>
</template>


<script>
import InventoryForm from "../../components/InventoryForm";
export default {
  components: {
    InventoryForm: InventoryForm
  }
};
</script>

<style>

.text{
  text-align: center;
}
.size{
  margin-left: 23%;
}
.position{
  position: absolute;
  top: 0;
}
</style>