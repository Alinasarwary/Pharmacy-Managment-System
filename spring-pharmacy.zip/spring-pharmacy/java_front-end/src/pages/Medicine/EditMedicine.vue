<template>
  <v-container fluid >
      <h1 class="text">Edit Medicine</h1><br>
      <v-flex d-flex lg10 sm6 class="size">
        <medicineForm :medicineId="Id"/>
        <MySnackbar text="Stock Details Modify Successfully!"/>
      </v-flex>
  </v-container>
</template>

<script>
import medicineForm from "../../components/MedicineForm"
export default {
    components:{
        medicineForm: medicineForm
    },
    data(){
        return{
            medicineId: this.$route.params.id
        }
    }
}
</script>

<style>

</style>