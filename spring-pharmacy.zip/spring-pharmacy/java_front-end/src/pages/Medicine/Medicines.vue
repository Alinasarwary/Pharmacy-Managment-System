<template>
  <v-flex d-flex lg12 sm6>
    <div>
    <h1 style="text-align: center" class="text">Medicines details</h1>
      <template>
        <div class="mx-3" align="center">
        <thead>
          <tr>
            <th class="text-left">Name</th>
            <th class="text-left">Company</th>
            <th class="text-left">Cost</th>
            <th class="text-left">Type</th>
            <th class="text-left">Composition</th>
            <th class="text-left">Description</th>
            <th class="text-left">Action</th>
          </tr>
        </thead>
        <tbody>
         <tr v-for="medicine in medicines" :key="medicine._id">
            <td>{{medicine.medicineName}}</td>
            <td>{{medicine.medicineCompany}}</td>
            <td>{{medicine.medicineCost}}</td>
            <td>{{medicine.medicineType}}</td>
            <td>{{medicine.medicineComposition}}</td>
            <td>{{medicine.medicineDescription}}</td>
            <td>
              <v-btn
                :to="{name: 'EditMedicine', params :{
                id:medicine._id
              }}"
                small
                color="primary"
                class="mr-2"
              >Edit</v-btn>
              <v-btn small color="warning" @click="deleteStock(stock._id)">Delete</v-btn>
            </td>
          </tr>
        </tbody>
        </div>
        <div class="text-center ma-2">
          <v-snackbar color="rgb(29, 41, 57)" right v-model="snackbar">
            {{text}}
            <template>
               <v-btn
              color="white"
              flat
              @click="showSnackbar = false">
              Close
               </v-btn>
            </template>
          </v-snackbar>
        </div>
      </template>
    </div>
  </v-flex>
</template>

<script>
import MedicineServices from '../../api/MedicineService'
export default {
  data(){
    return {
      medicine: [],
      snackbar: false,
      text: "Medicine deleted successfully!"
    }
  },

  methods: {
    async deleteMedicine(medicineId){
      const conf = confirm("Do you really want to delete ?");
      if(conf){
        const response = await MedicineServices.deleteById(medicineId);
        console.log(response.data);

        // this.medicine = this.medicine.filter(medicine => {
        //   return medicines._id !== medicineId;
        // });
        this.snackbar = true;
      }
    }
  }, 

  async mounted(){
    const response = await MedicineServices.getMedicine();
      this.medicine = response.data;      
  }
}
</script>

<style>
</style>