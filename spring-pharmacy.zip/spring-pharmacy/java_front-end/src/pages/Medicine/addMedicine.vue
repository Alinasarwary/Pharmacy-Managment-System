<template>
    <v-container class="position">
      <h2 class="text">Add New Medicine</h2>
        <v-flex d-flex lg10 sm6 class="size">
            <MedicineForm/>
            <MySnackbar text ="Stock is saved successfully!"/>
        </v-flex>
    </v-container>
</template>

<script>
import MySnackbar from "../../components/core/MySnackbar";
import MedicineForm from '../../components/MedicineForm.vue';

export default {
  components: {
    MySnackbar: MySnackbar,
    MedicineForm,
  }
};
</script>

<style>
.text{
  text-align: center;
}
.size{
  margin-left: 23%;
}
.position{
  position: absolute;
  top: 0;
}
</style>