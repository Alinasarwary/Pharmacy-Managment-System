<template>
    <v-container class="position">
      <h2 class="text">Stock Form</h2><br>
        <v-flex d-flex lg10 sm6 class="size">
            <stockForm/>
            <MySnackbar text ="Stock is saved successfully!"/>
        </v-flex>
    </v-container>
</template>

<script>
import stockForm from '../../components/StockForm';
import MySnackbar from "../../components/core/MySnackbar";

export default {
  components: {
    stockForm: stockForm,
    MySnackbar: MySnackbar,
  },
  // computed:{
  //   hide () {
  //     return this.$route.path === '/login' || this.$route.path === '/register'; 
  //   }
  // }
};
</script>

<style>
.text{
  text-align: center;
}
.size{
  margin-left: 23%;
}
.position{
  position: absolute;
  top: 0;
}
</style>