<template>
  <v-container fluid >
      <h1 class="text">Edit stock</h1><br>
      <v-flex d-flex lg10 sm6 class="size">
        <Form :stockId="stockId"/>
        <MySnackbar text="Stock Details Modify Successfully!"/>
      </v-flex>
  </v-container>
</template>


<script>
import Form from "../../components/StockForm";
import MySnackbar from "../../components/core/MySnackbar";
export default {
  components: {
    Form: Form,
    MySnackbar: MySnackbar
  },
  data() {
    return {
      stockId: this.$route.params.id
    };
  }
};
</script>

<style>
.text{
  text-align: center;
}
.size{
  margin-left: 23%;
}
</style>