<template>
  <v-flex d-flex lg12 sm8>
    <div>
      <div class="mb-3" align="center"><h1>Stock details</h1></div><br>
    
      <template>
        <div align="center">
          <thead >
            <tr>
              <th class="text-left">Number</th>
              <th class="text-left">Type</th>
              <th class="text-left">Items</th>
              <th class="text-left">Description</th>
              <th class="text-left">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="stock in stocks" :key="stock.id">
              <td>{{stock.stockNumber}}</td>
              <td>{{stock.stockType}}</td>
              <td>{{stock.stockItem}}</td>
              <td>{{stock.stockDescription}}</td>
              <td>
                <v-btn
                  :to="{name: 'EditStock', params :{
                  id:stock._id
                }}"
                  small
                  color="primary"
                  class="mr-2"
                >Edit</v-btn>
                <v-btn small color="warning" @click="deleteStock(stock._id)">Delete</v-btn>
              </td>
            </tr>
          </tbody>
        </div>
          <div class="text-center ma-2">
            <v-snackbar color="rgb(29, 41, 57)" right v-model="snackbar">
              {{text}}
              <template>
                <v-btn
                color="white"
                flat
                @click="showSnackbar = false">
                Close
                </v-btn>
              </template>
            </v-snackbar>
          </div>
      </template>
    </div>
  </v-flex>
</template>

<script>
import StockServices from "../../api/StockServices";
export default {
  data() {
    return {
      stocks: [],
      snackbar: false,
      text: "Stock removed successfully"
    };
  },
  methods: {
    async deleteStock(stockId){
      const conf = confirm("Do you really want to delete this Stock?");
      if(conf){
        const response = await StockServices.deleteById(stockId);
        console.log(response.data);

        this.stocks = this.stocks.filter(stock => {
          return stock._id !== stockId;
        });
        this.snackbar = true;
      }
    },
  },
  async mounted() {
    const response = await StockServices.getStock();
    this.stocks = response.data;
    console.log(response.data);
  }
};
</script>

<style>
td {
  border: 1px solid grey;
  font-size: 17px;
  text-align: center;
  padding: 0 10px 0 10px;
}
thead, th{
  border: 1px solid grey;
  background-color: grey;
  color: white;
  padding: 20px;
}
</style>