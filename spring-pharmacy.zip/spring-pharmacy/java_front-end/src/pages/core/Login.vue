<template>
<v-container fluid grid-list-xl id="login">
    <v-content >
      <v-container flueid>
        <v-layout align-center class="my-4">
            <v-card class="elevation-1 pa-5">
              <v-card-text>
                <div class="layout column align-center">
                  <h1 class="flex black--text">Login</h1>
                </div>
                <v-form>
                  <v-text-field
                    append-icon="person"
                    name="login"
                    label="Username, Email"
                    type="text"
                    v-model="userEmail"
                    :error="error"
                    :rules="[rules.required]"/>
                  <v-text-field
                    :type="hidePassword ? 'password' : 'text'"
                    :append-icon="hidePassword ? 'visibility_off' : 'visibility'"
                    name="password"
                    label="Password"
                    id="password"
                    :rules="[rules.required]"
                    v-model="password"
                    :error="error"
                    @click:append="hidePassword = !hidePassword"/>
                </v-form>
              </v-card-text>
              <v-card-actions>
                  <v-btn class="white--text mx-5 my-2" block color="#737373" @click="login" :loading="loading">Login</v-btn>
              </v-card-actions>
            </v-card>
        </v-layout>
      </v-container>
      <v-snackbar
        v-model="showResult"
        :timeout="2000"
        top>
        {{ result }}
      </v-snackbar>
    </v-content>
</v-container>
</template>

<script>
export default {
  props:["stockId"],
  components:{},
  data() {
    return {
      loading: false,
      userEmail: null,
      password: null,
      hidePassword: true,
      error: false,
      showResult: false,
      result: '',
      rules: {
        required: value => !!value || 'Required.'
      }
    }
  },

  methods: {
    async login() {
      const user = {
        username: this.username,
        password: this.password
      };

      await this.$store.dispatch("login", user);
      this.$router.push("/employee/all");
      const vm = this;

      if (!vm.userEmail || !vm.password) {

        vm.result = "Email and Password can't be null.";
        vm.showResult = true;

        return;
      }

      if (vm.userEmail === vm.$root.userEmail && vm.password === vm.$root.userPassword) {
        vm.$router.push({ name: 'Dashboard' });
      }
      else {
        vm.error = true;
        vm.result = "Email or Password is incorrect.";
        vm.showResult = true;
      }
    },

    async signin() {
      const user = {
        username: this.username,
        password: this.password
      };
      await this.$store.dispatch("login", user);
      this.$router.push("/employee/all");
    }
  }
}
</script>

<style>
  #login {
    background-image: url("../../images/pharmacy.jpg");
    background-size: 100% 100%;
    position: absolute;
    top: 0;
    left: 0;
  }
</style>
