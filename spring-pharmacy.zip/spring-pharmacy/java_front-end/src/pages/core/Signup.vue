<template>
  <v-container fluid grid-list-xl id="login">
    <v-content>
        <v-layout>
          <v-flex sm8>
            <v-card class="pa-5">
              <v-card-text>
                <div class="layout column align-center">
                  <h1 class=" black--text">Register yourself</h1>
                </div>
                <v-form>
                  <v-text-field
                    append-icon="person"
                    label="Fullname"
                    type="text"
                    v-model="fullname"
                    :error="error"
                    :rules="[rules.required]"/>
                  <v-text-field
                    append-icon="person"
                    label="Username"
                    type="text"
                    v-model="username"
                    :error="error"
                    :rules="[rules.required]"/>
                  <v-text-field
                    append-icon="email"
                    label="email"
                    type="text"
                    v-model="email"
                    :error="error"
                    :rules="[rules.required]"/>
                  <v-text-field
                    :type="hidePassword ? 'password' : 'text'"
                    :append-icon="hidePassword ? 'visibility_off' : 'visibility'"
                    name="password"
                    label="Password"
                    id="password"
                    :rules="[rules.required]"
                    v-model="password"
                    :error="error"
                    @click:append="hidePassword = !hidePassword"/>
                </v-form>
              </v-card-text>
              <v-card-actions>
                  <v-btn class="white--text mx-5 my-2" block  color="#737373" @click="signup" :loading="loading">Signup</v-btn>
              </v-card-actions>
            </v-card>
          </v-flex>
        </v-layout>
      <v-snackbar
        v-model="showResult"
        :timeout="2000"
        top>
        {{ result }}
      </v-snackbar>
    </v-content>
  </v-container>
</template>

<script>
export default {
  props:["stockId"],
  components:{},
  data() {
    return {
      loading: false,
      fullname:null,
      username: null,
      email: null,
      password: null,
      hidePassword: true,
      error: false,
      showResult: false,
      result: '',
      rules: {
        required: value => !!value || 'Required.'
      }
    }
  },

  methods: {
    async signup() {
        const user = {
          fullname: this.fullname,
          username: this.username,
          email: this.email,
          password: this.password
        };
        console.log(user);
        await this.$store.dispatch("signup", user);
        this.$router.push("/");


      const vm = this;

      if (!vm.userEmail || !vm.password) {

        vm.result = "Email and Password can't be null.";
        vm.showResult = true;

        return;
      }

      if (vm.userEmail === vm.$root.userEmail && vm.password === vm.$root.userPassword) {
        vm.$router.push({ name: 'Home' });
      }
      else {
        vm.error = true;
        vm.result = "Email or Password is incorrect.";
        vm.showResult = true;
      }
    },

  }
}
</script>

<style>
  #login {
    background-image: url("../../images/pharmacy.jpg");
    background-size: 100% 100%;
    position:absolute;
    top: 0;
    left: 0; 
  }
</style>
