<template>
  <v-container fluid grid-list-xl class="home">
    <v-layout row wrap>
      <!-- Widgets-->
      <!-- Widgets Ends -->
      <!-- Statistics -->
      <!-- Statistics Ends -->
      <!-- DataTable&TimeLine Starts -->
      <!-- <v-flex d-flex lg8 sm6 xs12>
        <data-table/>
      </v-flex> -->
      <!-- DataTable&TimeLine Ends -->
      <!-- <v-flex d-flex lg6 sm6 xs12>
        <stepper/>
      </v-flex> -->
    </v-layout>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      lorem: `Lorem ipsum dolor sit amet, mel at clita quando.`
    }
  }
}
</script>

<style>
.home{
  background-image: url("../images/pharmacy.jpg");
  height: 35em;
  background-size: 100% 100%;
}
</style>
