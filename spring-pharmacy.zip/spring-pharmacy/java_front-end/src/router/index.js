import Vue from 'vue';
import VueRouter from 'vue-router';

import Home from '../pages/home.vue';
import addStock from "../pages/Stock/addStock.vue";
import allStock from "../pages/Stock/stock.vue";
import editStock from "../pages/Stock/editSock.vue";
import login from "../pages/core/Login.vue";
import signup from "../pages/core/Signup.vue";
import addMedicine from "../pages/Medicine/addMedicine";
import Medicines from "../pages/Medicine/Medicines.vue";
import editMedicine from "../pages/Medicine/EditMedicine.vue";
import addInventory from "../pages/Inventory/addInventory.vue";
import inventory from "../pages/Inventory/inventories.vue";
import editInventory from "../pages/Inventory/EditInventory.vue";
import addCompany from "../pages/Company/addCompany.vue";
import company from "../pages/Company/companyList.vue";
import editCompany from "../pages/Company/editCompany.vue";


Vue.use(VueRouter);

const routes = [
    {
      path: '/',
      name: 'Home',
      component: Home,
      meta: {
        breadcrumb: [
          { name: 'Home' }
        ]
      }
    },

    //Stock Route
    {
      path: "/stock/add",
      name: 'AddStock',
      component: addStock,
    },
    {
      path: "/stock/all",
      name: 'Stock Details',
      component: allStock,
    },
    {
      path: "/stock/edit",
      name: "EditStockDetails",
      component: editStock,
    },

    //Medicines Route
    {
      path: "/medicine/add",
      name: "AddMedicine",
      component: addMedicine,
    },
    {
      path: "/medicine/all",
      name: "Medicines",
      component: Medicines,
    },
    {
      path: "/medicine/edit",
      name: "EditMedicineDetails",
      component: editMedicine,
    },

    //inventory route
    {
      path: "/inventory/add",
      name: "Add Inventory",
      component: addInventory,
    },
    {
      path: "/inventory/all",
      name: "Products",
      component: inventory,
    },
    {
      path: "/inventory/edit",
      name: "EditInventoryDetails",
      component: editInventory,
    },

    //company route
    {
      path: "/company/add",
      name: "Add Company",
      component: addCompany,
    },
    {
      path: "/company/all",
      name: "Companies",
      component: company,
    },
    {
      path: "/company/edit",
      name: "EditCompanyDetails",
      component: editCompany,
    },





    //login & signup route
    {
      path: "/user/login",
      name: "Login",
      component: login,
    },
    {
      path: "/user/register",
      name: "SignUp",
      component: signup,
    },
 
 
    
  ];

  const router = new VueRouter({
    mode: "history",
    base: process.env.BASE_URL,
    routes
  });

  router.beforeEach((to, from, next) => {
    const loggedIn = localStorage.getItem("user");
    if (to.matched.some(item => item.meta.authentication) && !loggedIn) {
      next("/");
    } else {
      next();
    }  
  });
  

export default router;
